import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('video review: currency picker uses the actual ISO code for flag rendering', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /flag\.textContent\s*=\s*currencyFlagForCode\(code\)/);
  assert.doesNotMatch(js, /currencyFlagForCode\(item\.code\)/);
});

test('video review: docked tool forms remain scrollable and reserve space below the final action', () => {
  const css = read('assets/css/rebuild-v98.63-hotfix.css');
  assert.match(css, /#screen-viewport>\.screen\.active \.calc-scrollable/);
  assert.match(css, /scroll-padding-bottom:calc\(28px \+ env\(safe-area-inset-bottom,0px\)\)/);
  assert.match(css, /overflow-y:auto!important/);
  assert.match(css, /#screen-viewport>\.screen\.active:has\(>\.dock-keypad\)>\.dock-keypad/);
});

test('video review: history cards use a stable expression/result grid instead of the broken flex row', () => {
  const css = read('assets/css/rebuild-v98.63-hotfix.css');
  assert.match(css, /#history-modal \.history-item\s*\{[\s\S]*?display:grid!important/);
  assert.match(css, /\.history-item-expression\{grid-column:1!important/);
  assert.match(css, /\.history-item-result\{grid-column:2!important/);
  assert.match(css, /#history-modal \.history-actions\{grid-column:1\/-1!important/);
});

test('video review: currency picker panel and list can shrink with the Android keyboard', () => {
  const css = read('assets/css/rebuild-v98.63-hotfix.css');
  assert.match(css, /\.sumaire-picker-panel\{[^}]*max-height:min\(88dvh,calc\(100dvh/);
  assert.match(css, /\.sumaire-picker-options\{flex:1 1 auto!important;min-height:0!important;overflow-y:auto!important/);
});

test('video review: service worker cache is migrated so installed clients fetch the corrected UI', () => {
  const sw = read('service-worker.js');
  const workflow = read('.github/workflows/main.yml');
  assert.match(sw, /sa-calculator-v98-63-live-currency-dock-fix-v98635/);
  assert.match(workflow, /sa-calculator-v98-63-live-currency-dock-fix-v98635/);
});
