'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const sw = fs.readFileSync(path.join(__dirname, '..', 'service-worker.js'), 'utf8');

test('navigation keeps a cached app shell available during transient HTTP 5xx failures', () => {
  assert.match(sw, /if\(fresh\.status>=500\)/);
  assert.match(sw, /const cached=\(await cache\.match\(req\)\)\|\|\(await cache\.match\('\.\/index\.html'\)\)/);
  assert.match(sw, /if\(cached\)return cached/);
});

test('navigation does not hide genuine 4xx responses behind the cached app shell', () => {
  const branch = sw.slice(sw.indexOf('if(page){'), sw.indexOf("   try{const fresh=await fetch(req)", sw.indexOf('if(page){')));
  assert.match(branch, /if\(fresh\.status>=500\)/);
  assert.match(branch, /return fresh/);
  assert.doesNotMatch(branch, /fresh\.status>=400/);
});
